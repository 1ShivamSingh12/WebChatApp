import { ShowErrorPipe } from './show-error.pipe';

describe('ShowErrorPipe', () => {
  it('create an instance', () => {
    const pipe = new ShowErrorPipe();
    expect(pipe).toBeTruthy();
  });
});
