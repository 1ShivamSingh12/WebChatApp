import { Component, Input, OnInit } from '@angular/core';
import { ChatServiceService } from 'src/app/service/chat-service.service';

@Component({
  selector: 'app-user1',
  templateUrl: './user1.component.html',
  styleUrls: ['./user1.component.scss']
})
export class User1Component implements OnInit {

  inputMessage:any
  // messageArray: Array<{ user: String; message: String }> = [];
  @Input() mydetail : any
  @Input() Message : any
  @Input() userDetail : any



  constructor(private chatService : ChatServiceService) { }

  ngOnInit(): void {
    console.log(this.mydetail,'kudgcuwcuiwcuwecue');
    console.log(this.userDetail , 'jhdvcvwqycvquywvxyvyuvyu');


  }

  message(){

    console.log(this.mydetail);
    this.mydetail = {...this.mydetail , message : this.inputMessage}
    console.log(this.mydetail,'llllllll');

    this.chatService.message(this.mydetail)

    this.inputMessage = ''

  }


  isThisMe(messageData:any):boolean{
    console.log(messageData,"MD");

    if(this.chatService.details.userID == messageData.userID ){
      return true;
    }else{
      return false;
    }

  }

}
