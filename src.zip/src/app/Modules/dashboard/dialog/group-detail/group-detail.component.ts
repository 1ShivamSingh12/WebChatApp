import { Component, OnInit } from '@angular/core';
import { ChatServiceService } from 'src/app/service/chat-service.service';

@Component({
  selector: 'app-group-detail',
  templateUrl: './group-detail.component.html',
  styleUrls: ['./group-detail.component.scss']
})
export class GroupDetailComponent implements OnInit {

  user:any
  group:any
  // messageArray: Array<{ user: String; message: String }> = [];

  constructor(private chatService : ChatServiceService) { }

  ngOnInit(): void {

  }


  joinRoom(){
    let detail = {username:this.user , Group : this.group}
    sessionStorage.setItem('Value' , JSON.stringify(detail))
    this.chatService.joinGroup({username:this.user , Group : this.group})
  }
}
