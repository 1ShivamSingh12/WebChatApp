export const CHAT_USERS_DATA = [
  {
      user_name:'Shivam',
      user_password:'123',
      user_chode : '100',
      user_chats:[
          {
              chat_name:'Swap',
              chat_type:'private',
              chat_code:'101'
          },
          {
              chat_name:'Ayush',
              chat_type:'private',
              chat_code:'102'
          },
          // {
          //     chat_name:'Arpit',
          //     chat_type:'private',
          //     chat_code:'103'
          // },
          // {
          //     chat_name:'arpit',
          //     chat_type:'private',
          //     chat_code:'104'
          // },
          // {
          //     chat_name:'raju',
          //     chat_type:'private',
          //     chat_code:'108'
          // }
      ]
  },

  {
      user_name:'Swapnil',
      user_password:'123',
      user_chode : '100',
      user_chats:[
          {
              chat_name:'shivam',
              chat_type:'private',
              chat_code:'101'
          },
          {
              chat_name:'ayush',
              chat_type:'private',
              chat_code:'102'

          },
          // {
          //     chat_name:'arpit',
          //     chat_type:'private',
          //     chat_code:'103'
          // },
          // {
          //     chat_name:'ayush',
          //     chat_type:'private',
          //     chat_code:'108'
          // }
      ]
  },
  {
    user_name:'Ayush',
    user_password:'123',
    user_chode : '100',
    user_chats:[
        {
            chat_name:'Swap',
            chat_type:'private',
            chat_code:'101'
        },
        {
            chat_name:'shivam',
            chat_type:'private',
            chat_code:'102'
        },
        // {
        //     chat_name:'Arpit',
        //     chat_type:'private',
        //     chat_code:'103'
        // },
        // {
        //     chat_name:'arpit',
        //     chat_type:'private',
        //     chat_code:'104'
        // },
        // {
        //     chat_name:'raju',
        //     chat_type:'private',
        //     chat_code:'108'
        // }
    ]
},
]
