import { AfterViewInit, Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CHAT_USERS_DATA } from 'src/app/constant/user_detail';
import { ChatServiceService } from 'src/app/service/chat-service.service';
import { GroupDetailComponent } from './dialog/group-detail/group-detail.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit,AfterViewInit {

  name:any
  messageArray: Array<{ user: String; message: String }> = [];
  groupDisplay = false
  user_list = CHAT_USERS_DATA
  room:any
  totalusers : any = []

  constructor(public dialog: MatDialog , private chatservice : ChatServiceService) {
    this.chatservice.newUserJoined().subscribe((data: any) => {
      this.messageArray.push(data);
    });
    this.chatservice.sendMessage().subscribe((data: any) => {
      console.log(data,"ui");

      this.messageArray.push(data);
    });
  }
  ngOnInit(): void {
    this.totalusers = this.chatservice.friends
  }


  ngAfterViewInit(): void {

  }


  newGroup : any
  dataSelected:any = {};
  display = false

  user : any[] = [];

  currentRoom:any

  userdata:any
  show(data:any){
    console.log(data,'total');

    if(this.groupName?.identify != 'group'){
      this.userdata = data
      let userData = {
        room:data.chat_code,
        user:this.chatservice.details.username,
      }
      this.currentRoom = data.chat_code;
      this.dataSelected = {
        room: this.currentRoom,
        user: this.chatservice.details.username,
      }
      this.chatservice.joinGroup(userData)
    }else{
      console.log(this.user,'lllllllllllllllllll');

      this.userdata = this.user
      const exist = this.userdata.findIndex((element:any)=> element.chat_name === data.chat_name);
      this.userdata[exist].chat_name = this.dataSelected.room
      console.log(this.userdata,'aaa');

      this.userdata  = this.userdata[exist]

      // console.log(this.user[exist],'ausyyyyyyyyyasuy');
    }

    this.messageArray = []
    this.display = true
  }

  groupDetail(){
    if(this.groupDisplay == false){
      this.groupDisplay = true
    }else if(this.groupDisplay == true){
      this.groupDisplay = false
    }
  }
  groupName:any

  joinRoom(){
    this.groupName = {chat_name : this.room , identify : 'group'}
    let userData = {user:this.name , room : this.room}
    this.dataSelected = userData
    console.log(this.dataSelected);

    this.user.push(this.groupName)
    this.chatservice.joinGroup({user:this.name , room : this.room})
    this.name = ''
    this.room = ''
  }
}
