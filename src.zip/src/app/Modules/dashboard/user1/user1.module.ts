import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { User1RoutingModule } from './user1-routing.module';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
// import { User1Component } from './user1.component';

@NgModule({
  declarations: [
    // User1Component
  ],
  imports: [
    CommonModule,
    User1RoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    FormsModule,
  ],
})
export class User1Module {}
