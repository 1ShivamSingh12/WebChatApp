export const environment = {
  production: true,
  SOCKET_ENDPOINT: 'http://localhost:8080'

};
