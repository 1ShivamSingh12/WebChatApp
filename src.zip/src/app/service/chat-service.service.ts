import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { io } from 'socket.io-client';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ChatServiceService {

  details : any = {
    username : '',
    password : '',
    userId :''
  }

  friends:any[] = []

  socket : any
  userID:any

  constructor() { }

  connection(){
    this.socket = io(environment.SOCKET_ENDPOINT)
    this.socket.on('ID', (data:string)=>{
      this.userID = data
    })
  }


  getID(){
    return this.userID
  }


  message(data: any) {
    this.socket.emit('message', data)
  }

  sendMessage() {
    let observable = new Observable<{user:string , message: String , userID : string }>(observer => {
      this.socket.on('new message', (data:any) => {
        console.log(data,"shi22");

        observer.next(data);
      });
      return () => { this.socket.disconnect(); }
    });

    return observable;
  }

  joinGroup(data:any){
    console.log(data,'join group');

    this.socket.emit('join' ,data)
  }

  newUserJoined()
  {
      let observable = new Observable<{user:String, message:String , userID  :String}>(observer=>{
          this.socket.on('new user joined', (data:any)=>{
            console.log(data,'efcjbbhbebcyeyceuucvv');

              observer.next(data);
          });
          return () => {this.socket.disconnect();}
      });

      return observable;
  }


}
