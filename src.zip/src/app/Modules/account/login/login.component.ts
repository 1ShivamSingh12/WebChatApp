import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CHAT_USERS_DATA } from 'src/app/constant/user_detail';
import { ChatServiceService } from 'src/app/service/chat-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private fb:FormBuilder , private chatService : ChatServiceService , private route : Router) { }
  loginForm!: FormGroup;

  allUsers : any[] = CHAT_USERS_DATA


  ngOnInit(): void {
    this.createForm()

    let userID = this.chatService.getID()
    this.chatService.details['userId'] = userID

  }

  createForm() {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(3)]],
    });
  }

  submit(){
    this.allUsers.map((user:any)=>{
      console.log(user.user_name,'pppp');

      if(user.user_name == this.loginForm.value.username && user.user_password == this.loginForm.value.password){
        this.chatService.friends = user.user_chats
        console.log(this.chatService.friends);

        this.chatService.details['username'] = this.loginForm.value.username
        this.chatService.details['password'] = this.loginForm.value.password

        this.route.navigate(['/dashboard'])
        console.log(this.chatService.details);

      }
    })
  }


}
